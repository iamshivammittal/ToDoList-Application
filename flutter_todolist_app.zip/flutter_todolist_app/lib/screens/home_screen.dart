import 'package:flutter/material.dart';
import 'package:fluttertodolistapp/helpers/drawers_navigation.dart';
import 'package:fluttertodolistapp/screens/todo_screen.dart';
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Todolist Sqflite'),
      ),
      drawer: DrawerNavigation(),
      floatingActionButton: FloatingActionButton(
        onPressed: ()=>Navigator.of(context).push(MaterialPageRoute(builder:(context)=>ToDoScreen())),
        child: Icon(Icons.add),
      ),
    );
  }
}
