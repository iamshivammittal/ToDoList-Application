import 'package:flutter/material.dart';
import 'package:fluttertodolistapp/services/category_service.dart';

class ToDoScreen extends StatefulWidget {
  @override
  _ToDoScreenState createState() => _ToDoScreenState();
}

class _ToDoScreenState extends State<ToDoScreen> {
  var todoTitleController=TextEditingController();

  var todoDateController=TextEditingController();
  var todoDescriptionController=TextEditingController();

  var _selectedValue;

  var _categories=List<DropdownMenuItem>();
@override
  void   initState(){
  super.initState();
  _loadCategories();
}
  _loadCategories()async{
    var _categoryService=CategoryService();
    var categories=await _categoryService.readCategories();
    // ignore: unnecessary_statements
    categories.forEach((category){
      setState((){
        _categories.add(DropdownMenuItem(
          child:Text(category['name']),
          value: category['name'],
        ));
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        title: Text('Create ToDo'),
      ),
      body: Padding(
        padding:  EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: todoTitleController,
              decoration: InputDecoration(
                labelText: 'Title',
                hintText: 'Write ToDo title'
              ),
            ),
            TextField(
              controller: todoDescriptionController,
              decoration: InputDecoration(
                  labelText: 'Description',
                  hintText: 'Write ToDo description'
              ),
            ),
            TextField(
              controller: todoDateController,
              decoration: InputDecoration(
                  labelText: 'Date',
                  hintText: 'Pick a Date',
                prefixIcon: InkWell(
                  onTap: (){},
                  child: Icon(Icons.calendar_today),
                ),
              ),
            ),
            DropdownButtonFormField(
              value: _selectedValue,
              items: _categories,
              hint:Text('Category'),
              onChanged: (value){
                setState(() {
                  _selectedValue=value;
                });
              },
            ),
            SizedBox(
              height:20,
            ),
            RaisedButton(onPressed:(){},color:Colors.blue,
                child:Text('Saved',style:TextStyle(color:Colors.white),)
            )
          ],
        ),
      ),
    );
  }
}
